/*
 * MiniProject1Task1Newmethod.c
 *
 * Created: 19-Mar-21 10:30:31 PM
 * Author : HP
 */ 
#define F_CPU 1000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRD=0b00000011;
	DDRB=0b11111111;
	//DDRC=0b00000001;
	
    /* Replace with your application code */
    while (1) 
    {
		
	  
	//	_delay_ms(4000);
		 //1 g f e d c b a
		//PORTD=0b11000000; 
	        //0
    	PORTB=0b11000000;       // 0
        PORTD=0x00;  
		
		_delay_ms(50);         
	    
		
		PORTD=0x01; 
		PORTB=0b11111001;             //1


	 _delay_ms(50);
	 
	 
		PORTD=0x02;
	  PORTB=0b10100100;            //2

 _delay_ms(50);	
		  
		  PORTB=0b10110000;
		PORTD=0x03;
            //3
		
	 _delay_ms(50);
		
    }
}

